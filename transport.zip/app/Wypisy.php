<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wypisy extends Model
{
    //
}
