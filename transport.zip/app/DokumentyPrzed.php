<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DokumentyPrzed extends Model
{
    //
}
