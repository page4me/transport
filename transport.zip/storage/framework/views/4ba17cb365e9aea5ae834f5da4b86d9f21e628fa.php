<?php $__env->startSection('content'); ?>
<div class="container">
<div class="card uper">
  <div class="card-header bg-dark text-light" >
  <?php $__currentLoopData = $rodzaje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $petent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   Dane szczegółowe przedsiębiorcy -
     <span style="color: #00ddff;font-size:16px;"> Nr licencji / zezwolenia:
       <?php $__currentLoopData = $dok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php echo e($dk->nr_dok); ?>

      
     </span><span style="color: #fff;font-size:16px;">wydano dn. <?php echo e($dk->data_wyd); ?>   r.</span>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="card-body">
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
       <div class="row">
          <div class=" col-md-3">
              <label for="Nazwa firmy"><strong>Nazwa firmy - zgodnie z CEIDG: <br />Rodzaj:</strong>
               <?php $__currentLoopData = $osobowosc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($row->rodzaj); ?>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
             </label>
              <div><?php echo e($przedsiebiorca->nazwa_firmy); ?><br /><?php echo e($przedsiebiorca->adres); ?><br /><?php echo e($przedsiebiorca->kod_p); ?> <?php echo e($przedsiebiorca->miejscowosc); ?></div><br />
              <div><strong>NIP:</strong> <?php echo e($przedsiebiorca->nip); ?></div>
              <div><strong>REGON:</strong> <?php echo e($przedsiebiorca->regon); ?></div>
          </div>
          <div class="col-md-3">
              <strong>Własciciel:</strong><br />
              <?php echo e($przedsiebiorca->nazwisko); ?> <?php echo e($przedsiebiorca->imie); ?> <br />
              <strong>Dane kontatkowe:</strong><br />
              telefon: +48 <?php echo e($przedsiebiorca->telefon); ?> <br />
              e-mail: <?php echo e($przedsiebiorca->email); ?>

              <br />
              <br />
               <div>
                 <strong>Wydanych wypisów:</strong>
                   <span class="badge badge-success" style="font-size:12px;"> 11 </span><br />
                 <strong>W depozycie wypisów: </strong><span class="badge badge-danger" style="font-size:12px;"> 2</span>
               </div>
          </div>
          <div class="col-md-3">
             <div><strong>Osoba zarządzająca</strong></div>
             <div>
              <?php $__currentLoopData = $cert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!empty($ck->id)): ?> <?php echo e($ck->imie_os_z); ?> <?php echo e($ck->nazwisko_os_z); ?> <?php else: ?> brak <?php endif; ?> 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </div>
             <div>Umowa do dnia -  <?php if(!empty($ck->id)): ?> <?php echo e($ck->umowa); ?> <?php else: ?> brak <?php endif; ?></div> 
             <div><strong>Certyfikat kompetencji:</strong><br /><?php if(!empty($ck->id)): ?><span style="color:#0041a8;font-weight: bold;"><?php echo e($ck->rodzaj); ?></span><?php else: ?> brak <?php endif; ?> / Nr <?php if(!empty($ck->id)): ?> <?php echo e($ck->nr_cert); ?> <?php else: ?> brak <?php endif; ?></div><br />
            
              <div>
                 <strong>Ilosć pojazdów:</strong>
                   <span class="badge badge-success" style="font-size:12px;"> 8 </span><br />&nbsp;
                     <a class="btn btn-sm btn-primary" href="/przedsiebiorca/cars/<?php echo e($przedsiebiorca->id); ?>">Wykaz pojazdów</a>
              </div>
          </div>
          <div class="col-md-3">
             <div><strong>Baza eksploatacyjna</strong></div>
              <div><strong>Adres:</strong> <br />ul.Koszalińska 32 <br />75-900 Koszalin</div>
             <div>Umowa do dnia 25.09.2019 r.</div>
             <br />
             <div><strong>Zabezpieczenie finansowe:</strong> Bilans</div>
             <div>19 000 &euro; - 2 pojazdy</div>
             <div><span class="badge badge-success" style="font-size:14px;">Do dnia 25.09.2020 r.</span></div>
          </div>
      </div>
    </div>
     <div class="card-header bg-dark text-light">

           <div class="col-md-12 bg-dark" style="color:#fff;font-size: 15px;">Dane licencji / zezwolenia</strong>  - <span class="badge badge-warning" style="font-size:13px;">  <?php echo e(strtoupper($dk->rodz_dok)); ?> </span></div>
    </div>
    <div class="card-body">
           <div class="row">
             <div class="col-md-3">
               <strong>Data wydania : </strong><br /><span class="badge badge-secondary" style="font-size:14px;"> 
                  <?php echo e($dk->data_wyd); ?>

               </span>
             </div>
              <div class="col-md-3">
               <strong>Ważnsć do dnia: </strong><br /><span class="badge badge-success" style="font-size:14px;"> <?php echo e($dk->data_waz); ?></span>
             </div>
              <div class="col-md-3">
               <strong>Numer sprawy: </strong><br />  <?php echo e($dk->nr_sprawy); ?>

             </div>
              <div class="col-md-3">
               <strong>Numer dokumentu: </strong><br /><strong> <span style="color:#17aa06;"> <?php echo e($dk->nr_dok); ?>

              </span> /   <?php echo e($dk->nr_druku); ?> </strong></span>
             </div>
             <div class="col-md-12 text-center"><br /><a href="<?php echo e(url('ganerate-pdf')); ?>" role="button" class="btn btn-primary btn-sm">Historia zmian</a></div>
           </div>
    </div>
    <div class="card-header bg-dark text-light">

           <div class="col-md-12 bg-dark" style="color:#fff;font-size: 15px;">Kontrole</strong></div>
    </div>
    <div class="card-body">
           <div class="row">
             <div class="col-md-3">
               <strong>Przeprowadzenie kontroli: </strong><br /><span class="badge badge-secondary" style="font-size:14px;"> 25.05.2019 r. </span>
             </div>
              <div class="col-md-3">
               <strong>Kolejna kontrola: </strong><br /><span class="badge badge-warning" style="font-size:14px;"> 25.05.2024 r.</span>
             </div>
              <div class="col-md-3">
               <strong>Wyniki kontroli: </strong><br /><span class="badge badge-success" style="font-size:14px;"> Spełnia wymagania </span>
             </div>
              <div class="col-md-3">
               <strong>Zalecenia pokontrolne: </strong><br /><span class="badge badge-success" style="font-size:14px;"> Nie </span>
             </div>
             <div class="col-md-12 text-center"><br /><a href="#" role="button" class="btn btn-primary btn-sm">Podgląd wyników kontroli</a></div>
           </div>
    </div>

    </div>
    <div><a class="btn btn-primary" href="/przedsiebiorca" role="button">Powrót do listy przedsiębiorców</a></div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\transport\resources\views/przedsiebiorca/show.blade.php ENDPATH**/ ?>