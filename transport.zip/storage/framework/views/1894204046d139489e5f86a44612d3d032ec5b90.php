<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div>
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>

    </div><br />
  <?php endif; ?>
  <div class="card bg-dark text-white">
    <div class="card-body">Przedsiębiorcy - <a href="przedsiebiorca/create" role="button" class="btn btn-success">Dodaj nowego</a></div>
  </div>
 <div class="table-responsive">
  <table class="table table-bordered table-sm">
    <thead class="table-primary" style="font-weight:bold;">
        <tr>
          <td>Nr licencji</td>
          <td>Nazwa firmy</td>
          <td>Imię</td>
          <td>Nazwisko</td>
          <td>Adres</td>
          <td>Miejscowosć</td>
          <td>NIP</td>
          <td>REGON</td>
          <td>Telefon<td>
          <td colspan="3">Akcja</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $przedsiebiorca; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $petent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><strong>
              <?php $__currentLoopData = $rodzaje; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($petent->id == $row->id): ?>
                  <?php echo e($row->nr_dok); ?>

                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </strong></td>
            <td><?php echo e($petent->nazwa_firmy); ?></td>
            <td><?php echo e($petent->imie); ?></td>
            <td><?php echo e($petent->nazwisko); ?></td>
            <td><?php echo e($petent->adres); ?></td>
            <td><?php echo e($petent->miejscowosc); ?></td>
            <td><?php echo e($petent->nip); ?></td>
            <td><?php echo e($petent->regon); ?></td>
            <td>+48 <?php echo e($petent->telefon); ?></td>
            <td><a href="<?php echo e(route('przedsiebiorca.edit',$petent->id)); ?>" class="btn btn-sm btn-success">Edytuj</a></td>
            <td><form action="<?php echo e(route('przedsiebiorca.destroy', $petent->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-sm btn-danger" type="submit">Usuń</button>
                </form>
            </td>
            <td><a href="<?php echo e(route('przedsiebiorca.show',$petent->id)); ?>" class="btn btn-sm btn-primary">Podgląd</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\transport\resources\views/przedsiebiorca/index.blade.php ENDPATH**/ ?>